# To be able to omit cv2 in code, use the following import statement (not recommended)
#from cv2 import *

# Otherwise use the following
import cv2

print(cv2.getBuildInformation())